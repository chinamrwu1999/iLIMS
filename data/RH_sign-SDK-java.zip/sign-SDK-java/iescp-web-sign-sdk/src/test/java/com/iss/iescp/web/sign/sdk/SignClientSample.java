package com.iss.iescp.web.sign.sdk;
import com.iss.iescp.web.sign.sdk.bas.SignClientException;
import com.iss.iescp.web.sign.sdk.bas.SignServerException;
import com.iss.iescp.web.sign.sdk.client.PcisServiceClient;

/**
 * @file SignSample.java
 * @author:bbwangt@isoftstone.com
 * @Description:sign sample  
 * @date :2017-11-14
 **/
public class SignClientSample {
    public static void main(String[] args){
    	//从服务方得到的API密钥信息
        String secretId="secret_id_111111";
        String secretKey="secret_key_111111";
        //服务方提供的验签服务访问地址
        //String endpoint = "http://localhost:8080";
        String endpoint = "https://api.rhassurance.com:6666";
        String result=null;
        try{
    		PcisServiceClient client = new PcisServiceClient(endpoint,secretId, secretKey);
    		
    		//洁牙服务回调预约接口
    		//result=client.callService("HealthCleanTeethService.manualBindCards","");
    		//产品大类查询接口
    		result=client.callService("ProdQueryService.qryProdKindList","");
    		System.out.println(result);

        }catch(SignServerException e1){//加签服务器抛出的异常
            System.out.println("Sign Server Exception： " + e1.toString());
        }catch(SignClientException e2){//加签SDK客户端抛出的异常
            System.out.println("Sign Client Exception： " + e2.toString());
        }catch (Exception e) {
    			System.out.println("error..." + e.toString());
    	}
        
    }
}
