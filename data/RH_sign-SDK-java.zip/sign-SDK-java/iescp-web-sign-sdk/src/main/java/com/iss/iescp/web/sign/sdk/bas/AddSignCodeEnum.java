package com.iss.iescp.web.sign.sdk.bas;

public enum  AddSignCodeEnum  implements ISignEnum{
	SUCCESS("0000","成功"),
	URL_ERROR("4001","URL错误"),
	NOT_CONFIG("4002","服务未配置"),
	SECRET_ERROR("4003","密钥失效或过期"),
	NO_ACTION("4004","缺少Action参数"),
	NO_METHOD("4005","缺少RequestMethod参数"),
	ADD_ERROR("4006","加签出错"),
	TIME_OUT("5001","请求超时"),
	SERVICE_ERROR("5002","外部服务报错");
	
	private final String value;
	private final String name;
	
	private AddSignCodeEnum(String value,String name){
		this.value=value;
		this.name=name;
	}
	
    public static String getName(String value) {
        for (ISignEnum c : AddSignCodeEnum.values()) {
        	if (c.getValue().equals(value)) {
                return c.getName();
            }
        }
        return null;
    }
    public static String getValue(String name) {
        for (ISignEnum c : AddSignCodeEnum.values()) {
            if (c.getName().equals(name)) {
                return c.getValue();
            }
        }
        return null;
    }

	@Override
	public String getValue() {
		return value;
	}

	@Override
	public String getName() {
		return name;
	}



}
