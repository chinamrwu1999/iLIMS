package com.iss.iescp.web.sign.sdk.bas;

public enum  SignMethodEnum  implements ISignEnum{
	SHA256("HmacSHA256","SHA256"),
	SHA1("HmacSHA1","SHA1");
	
	private final String value;
	private final String name;
	
	private SignMethodEnum(String value,String name){
		this.value=value;
		this.name=name;
	}
	
    public static String getName(String value) {
        for (ISignEnum c : SignMethodEnum.values()) {
        	if (c.getValue().equals(value)) {
                return c.getName();
            }
        }
        return null;
    }
    public static String getValue(String name) {
        for (ISignEnum c : SignMethodEnum.values()) {
            if (c.getName().equals(name)) {
                return c.getValue();
            }
        }
        return null;
    }

	@Override
	public String getValue() {
		return value;
	}

	@Override
	public String getName() {
		return name;
	}



}
