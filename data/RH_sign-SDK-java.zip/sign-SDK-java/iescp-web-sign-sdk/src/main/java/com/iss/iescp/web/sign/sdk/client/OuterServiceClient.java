package com.iss.iescp.web.sign.sdk.client;
import java.net.URLEncoder;
import java.util.Map;
import java.util.TreeMap;

import com.iss.iescp.web.sign.sdk.bas.CheckSignCodeEnum;
import com.iss.iescp.web.sign.sdk.bas.SignClient;
import com.iss.iescp.web.sign.sdk.bas.SignClientConstant;
import com.iss.iescp.web.sign.sdk.bas.SignClientException;
import com.iss.iescp.web.sign.sdk.bas.SignHttp;
import com.iss.iescp.web.sign.sdk.bas.SignMethodEnum;
import com.iss.iescp.web.sign.sdk.bas.SignServerException;
import com.iss.iescp.web.sign.sdk.json.JSONObject;

//******************************************************************
/**
 *类名:com.iss.iescp.web.sign.sdk.client.OuterServiceClient<br>
 * 描述:PCIS通过加签调用外部服务通用客户端
 * 	基本思路:
 * 	public方法:
 * 	特别说明:
 * 编写者: 汪彬彬
 * 版权: Copyright (C) 2017  软通动力 版权所有
 * 创建时间:2017年12月4日 下午11:02:05
 * 修改说明:类的修改说明
 * </pre>
 */
//******************************************************************
public class OuterServiceClient {
	/** 加签服务路径 */
	private static final String ADD_SIGN_PATH="/addsign/v1";
    
    
    
    
    //**************************************************************************
    /**
     * 通过加签后调用外部服务通用方法<br>
     * 
     * @param String serviceName 服务名，格式：服务类名.服务方法名
     * @param String serviceParam 服务参数，JSON格式字符串
     * @return String 返回值 返回JSON格式字符串
     */
    //**************************************************************************
    public String callService(String endpoint,Map paramMap,String serviceName,String requestMethod) throws Exception
    {
		String url = "";
		String req = "";
		boolean flag = false;
		String result =null;
		try{
	
	    	TreeMap<String, String> param = new TreeMap(paramMap);
			param.put(SignClientConstant.PARAM_ACTION,serviceName);
			param.put(SignClientConstant.PARAM_REQUEST_METHOD,requestMethod);
			url = endpoint+ADD_SIGN_PATH;
			flag = false;
			for(String key: param.keySet()){
				if(flag)
					req += "&";
				req += key + "=" + URLEncoder.encode(param.get(key),SignClientConstant.DATA_ENCODE);
				flag = true;
			}
	
	
			result = SignHttp.request(SignClientConstant.REQ_METHOD_POST, url, req);
		}catch (Exception e) {
			
		}
		if(result!=null && result.indexOf(SignClientConstant.PARAM_SIGN_CODE)>0 && result.indexOf(SignClientConstant.PARAM_SIGN_MSG)>0) {
			JSONObject jsonObj = new JSONObject(result);
			String signStatus = jsonObj.getString(SignClientConstant.PARAM_SIGN_CODE);
			String signMsg=jsonObj.getString(SignClientConstant.PARAM_SIGN_MSG);
			String reqId=jsonObj.getString(SignClientConstant.PARAM_REQ_ID);
			throw new SignServerException(signStatus,signMsg,reqId);
		}
	    return result;
    }
   
}
