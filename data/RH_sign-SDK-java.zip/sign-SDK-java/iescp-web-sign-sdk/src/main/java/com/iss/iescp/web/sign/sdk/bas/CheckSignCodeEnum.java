package com.iss.iescp.web.sign.sdk.bas;

public enum  CheckSignCodeEnum  implements ISignEnum{
	SUCCESS("0000","成功"),
	NOT_AUTH("1001","身份认证失败"),
	NOT_GRANT("1002","未被开发商授权访问本接口"),
	NOT_GRANT_RES("1003","未被开发商授权访问本接口中所操作的资源"),
	NO_SECRET("1004","SecretId 不存在"),
	GRANT_ERROR("1005","鉴权失败"),
	REPEAT_SEND("1006","重放攻击错误"),
	TIME_OUT("1007","发送超时错误"),
	INNER_ERROR("2001","接口内部错误");
	
	private final String value;
	private final String name;
	
	private CheckSignCodeEnum(String value,String name){
		this.value=value;
		this.name=name;
	}
	
    public static String getName(String value) {
        for (ISignEnum c : CheckSignCodeEnum.values()) {
        	if (c.getValue().equals(value)) {
                return c.getName();
            }
        }
        return null;
    }
    public static String getValue(String name) {
        for (ISignEnum c : CheckSignCodeEnum.values()) {
            if (c.getName().equals(name)) {
                return c.getValue();
            }
        }
        return null;
    }

	@Override
	public String getValue() {
		return value;
	}

	@Override
	public String getName() {
		return name;
	}



}
