
package com.iss.iescp.web.sign.sdk.bo;

import java.util.Map;

import com.iss.iescp.web.sign.sdk.bas.CheckSignCodeEnum;

//******************************************************************
/**
 *类名:com.iss.iescp.web.sign.sdk.bo.CheckSignResult<br>
 * 描述:验签结果类
 * 	基本思路:
 * 	public方法:
 * 	特别说明:
 * 编写者: 汪彬彬
 * 版权: Copyright (C) 2017  软通动力 版权所有
 * 创建时间:2017年11月23日 下午5:06:20
 * 修改说明:类的修改说明
 * </pre>
 */
//******************************************************************
public class CheckSignResult {
	
	
    /** 返回结果编码,参考 CheckSignCodeEnum */
    protected String signCode=CheckSignCodeEnum.SUCCESS.getValue() ;
	
    /** 消息字符串*/
    protected String signMsg = CheckSignCodeEnum.SUCCESS.getName();

    /** 请求ID*/
    protected String reqId = null;
	
    /** 请求参数*/
    protected Map reqParams = null;

	public String getSignCode() {
		return signCode;
	}

	public void setSignCode(String signCode) {
		this.signCode = signCode;
	}

	public String getSignMsg() {
		return signMsg;
	}

	public void setSignMsg(String signMsg) {
		this.signMsg = signMsg;
	}

	public Map getReqParams() {
		return reqParams;
	}

	public void setReqParams(Map reqParams) {
		this.reqParams = reqParams;
	}

	public String getReqId() {
		return reqId;
	}

	public void setReqId(String reqId) {
		this.reqId = reqId;
	}

	public CheckSignResult(CheckSignCodeEnum code,String msg,String reqId, Map reqParams) {
		super();
		this.signCode = code.getValue();
		this.signMsg = code.getName()+":"+msg;
		this.reqId=reqId;
		this.reqParams = reqParams;
	}
    
    








    
    
    
    
    
	
	

}
