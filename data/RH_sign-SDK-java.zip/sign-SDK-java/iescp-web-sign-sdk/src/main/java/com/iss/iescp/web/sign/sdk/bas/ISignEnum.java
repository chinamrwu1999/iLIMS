package com.iss.iescp.web.sign.sdk.bas;

public interface ISignEnum {
	String getValue();
	String getName();
}
