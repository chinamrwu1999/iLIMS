package com.iss.iescp.web.sign.sdk.client;
import java.util.TreeMap;

import com.iss.iescp.web.sign.sdk.bas.CheckSignCodeEnum;
import com.iss.iescp.web.sign.sdk.bas.SignClient;
import com.iss.iescp.web.sign.sdk.bas.SignClientConstant;
import com.iss.iescp.web.sign.sdk.bas.SignMethodEnum;
import com.iss.iescp.web.sign.sdk.bas.SignServerException;
import com.iss.iescp.web.sign.sdk.json.JSONObject;

//******************************************************************
/**
 *类名:com.iss.iescp.web.sign.sdk.client.PcisServiceClient<br>
 * 描述:PCIS服务通用客户端
 * 	基本思路:
 * 	public方法:
 * 	特别说明:
 * 编写者: 汪彬彬
 * 版权: Copyright (C) 2017  软通动力 版权所有
 * 创建时间:2017年12月4日 下午11:02:18
 * 修改说明:类的修改说明
 * </pre>
 */
//******************************************************************
public class PcisServiceClient {
	/** 验签服务路径 */
	private static final String CHECK_SIGN_PATH="/checksign/v1";
	
    protected SignClient client;
    public PcisServiceClient(String endpoint , String secretId, String secretKey)
    {
    	this.client = new SignClient(endpoint, CHECK_SIGN_PATH, secretId, secretKey, SignClientConstant.REQ_METHOD_POST);
    }

    public PcisServiceClient(String secretId, String secretKey,String endpoint, String path, String method)
    {
		this.client = new SignClient(endpoint, path, secretId, secretKey, method);
	}

    /**
     * setSignMethod set the sign meth and now we suppport sha1 and sha256
     **/
    
    public void setSignMethod(SignMethodEnum signMethod)
    {
    	this.client.setSignMethod(signMethod);
    }
    
    
    
    
    //**************************************************************************
    /**
     * 调用服务通用方法<br>
     * 方法callService详细说明
     * @param String serviceName 服务名，格式：服务类名.服务方法名
     * @param String serviceParam 服务参数，JSON格式字符串
     * @return String 返回值 返回JSON格式字符串
     */
    //**************************************************************************
    public String callService(String serviceName,String serviceParam) throws Exception
    {
    	TreeMap<String, String> param = new TreeMap<String, String>();
		param.put(SignClientConstant.PARAM_Z_DATA,serviceParam);
		String result = this.client.call(serviceName, param);
		if(result!=null && result.indexOf(SignClientConstant.PARAM_SIGN_CODE)>0 && result.indexOf(SignClientConstant.PARAM_SIGN_MSG)>0) {
			JSONObject jsonObj = new JSONObject(result);
			String signStatus = jsonObj.getString(SignClientConstant.PARAM_SIGN_CODE);
			String signMsg=jsonObj.getString(SignClientConstant.PARAM_SIGN_MSG);
			String reqId=jsonObj.getString(SignClientConstant.PARAM_REQ_ID);
			throw new SignServerException(signStatus,signMsg,reqId);
		}
	    return result;
    }
   
}
