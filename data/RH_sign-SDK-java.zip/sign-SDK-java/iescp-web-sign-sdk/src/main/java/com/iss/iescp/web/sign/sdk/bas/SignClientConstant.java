package com.iss.iescp.web.sign.sdk.bas;

public class SignClientConstant {
	
	/** 数据编码 */
	public static final String DATA_ENCODE="utf-8";
	

	/** 请求协议：http */
	public static final String REQ_PTC_HTTP="http";
	/** 请求协议：https */
	public static final String REQ_PTC_HTTPS="https";
	/** 请求方法：GET */
	public static final String REQ_METHOD_GET="GET";
	/** 请求方法：POST */
	public static final String REQ_METHOD_POST="POST";
	
	//======================  请求参数名 start ======================
	/** 参数名：请求接口名，格式为：服务名.方法名 */
	public static final String PARAM_ACTION="Action";
	/** 参数名：随机正整数，全局唯一的，至少8位 */
	public static final String PARAM_NONCE="Nonce";
	/** 参数名：密钥ID */
	public static final String PARAM_SECRET_ID="SecretId";
	/** 参数名：当前时间戳，精确到秒，与服务器时间相差不能超过5分钟 */
	public static final String PARAM_TIMESTAMP="Timestamp";
	/** 参数名：客户端版本号 */
	public static final String PARAM_CLIENT_VERSION="ClientVersion";
	/** 参数名：签名方法，不为HmacSHA256，否则为HmacSHA1 */
	public static final String PARAM_SIGNATURE_METHOD="SignatureMethod";
	/** 参数名：签名串，签名算法生成 */
	public static final String PARAM_SIGNATURE="Signature";
	
	/** 参数名：业务参数名，所有服务默认的参数名 */
	public static final String PARAM_Z_DATA="ZData";
	/** 参数名：请求地址 */
	public static final String PARAM_REQUEST_URL="RequestUrl";
	/** 参数名：请求方法，GET或者POST */
	public static final String PARAM_REQUEST_METHOD = "RequestUrl";
	
	/** 参数名：返回结果的签名状态编码 */
	public static final String PARAM_SIGN_CODE="signCode";
	/** 参数名：返回结果的消息 */
	public static final String PARAM_SIGN_MSG="signMsg";
	/** 参数名：返回结果的请求ID */
	public static final String PARAM_REQ_ID="reqId";

	//======================  请求参数名 end ======================

	/** 时间戳最大相差秒数,5分钟 */
	public static final long TIMESTAMP_MAX_SUB=300L;






}
