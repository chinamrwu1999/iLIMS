package com.iss.iescp.web.sign.sdk.bas;
import java.util.TreeMap;
import java.util.Random;
import java.net.URLEncoder;

public class SignClient {
	protected String CURRENT_VERSION = "SDK_JAVA_1.0";

	protected String endpoint;
	protected String path;
	protected String secretId;
	protected String secretKey;
	protected String method;
	protected String signMethod;


	public SignClient(String endpoint, String path, String secretId, String secretKey, String method){
		this.endpoint = endpoint;
		this.path = path;
		this.secretId = secretId;
		this.secretKey = secretKey;
		this.method = method;
		this.signMethod = SignMethodEnum.SHA1.getValue();;
	}
	
	public void setSignMethod(SignMethodEnum signMethod)
	{
		if(signMethod==null)
		{
		    throw new SignClientException("sign method parameter is null");
		}
		else
		{
			this.signMethod = signMethod.getValue();
		}		   
	}

	public String call(String action, TreeMap<String,String> param) throws Exception{
		String rsp = "";
		try{
			param.put(SignClientConstant.PARAM_ACTION, action);
			param.put(SignClientConstant.PARAM_NONCE, Integer.toString(new Random().nextInt(java.lang.Integer.MAX_VALUE)));
			param.put(SignClientConstant.PARAM_SECRET_ID, this.secretId);
			param.put(SignClientConstant.PARAM_TIMESTAMP, Long.toString(System.currentTimeMillis() / 1000));
			param.put(SignClientConstant.PARAM_CLIENT_VERSION, this.CURRENT_VERSION);
			
			if(SignMethodEnum.SHA256.getValue().equals(this.signMethod))
				param.put(SignClientConstant.PARAM_SIGNATURE_METHOD,SignMethodEnum.SHA256.getValue());
			else
				param.put(SignClientConstant.PARAM_SIGNATURE_METHOD,SignMethodEnum.SHA1.getValue());

			String host="";
			if(this.endpoint.startsWith(SignClientConstant.REQ_PTC_HTTPS))
				host = this.endpoint.substring(8);
			else
				host = this.endpoint.substring(7);
			String src = "";
			src += this.method + host + this.path + "?";

			boolean flag = false;
			for(String key: param.keySet()){
				if(flag)
					src += "&";
				src += key.replace("_", ".") + "=" + param.get(key);
				flag = true;
			}
			param.put(SignClientConstant.PARAM_SIGNATURE,SignTool.sign(src, this.secretKey,this.signMethod));
			String url = "";
			String req = "";
			if(this.method.equals(SignClientConstant.REQ_METHOD_GET)){
				url = this.endpoint + this.path + "?";
				flag = false;
				for(String key: param.keySet()){
					if(flag)
						url += "&";
					url += key + "=" + URLEncoder.encode(param.get(key),SignClientConstant.DATA_ENCODE);
					flag = true;
				}
				if(url.length() > 2048)
					throw new SignClientException("URL length is larger than 2K when use GET method");
			}
			else{
				url = this.endpoint + this.path;
				flag = false;
				for(String key: param.keySet()){
					if(flag)
						req += "&";
					req += key + "=" + URLEncoder.encode(param.get(key),SignClientConstant.DATA_ENCODE);
					flag = true;
				}
			}

			//验签
			String paramSignature = param.get(SignClientConstant.PARAM_SIGNATURE);
			param.remove(SignClientConstant.PARAM_SIGNATURE);
			TreeMap<String,String> orderParams=new TreeMap(param);//排序参数

			//请求方法 + 请求主机 +请求路径 + ? + 请求字符串
			StringBuffer src1 =new StringBuffer();
			//src += this.method + host + this.path + "?";
			src1.append(this.method).append(host).append(this.path).append("?");
			boolean flag1 = false;
			for(String key: orderParams.keySet()){
				if(flag1){
					src1.append("&");
				}
				src1.append(key.replace("_", ".")).append("=").append(orderParams.get(key));
				flag1 = true;
			}
			String signData=src1.toString();
			System.out.println("444："+signData);
			//生成签名
			String signatrueMethod=param.get(SignClientConstant.PARAM_SIGNATURE_METHOD);
			String checkSignature=SignTool.sign(signData, secretKey,signatrueMethod);
			if(!paramSignature.equals(checkSignature)) {
				String msg="验签未通过，请检查参数";
				System.out.println("00000："+msg);
				throw new Exception("验签未通过，请检查参数");
			} else {
				System.out.println("验签通过，成功！！！！");
			}
			

			rsp = SignHttp.request(this.method, url, req);

		}catch(Exception e){
			throw e;
		}
		return rsp;
	}
}
