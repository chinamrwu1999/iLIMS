package com.iss.iescp.web.sign.sdk.bas;


public class SignClientException extends RuntimeException{

	public SignClientException(String message) {
        super(message);
    }
}
